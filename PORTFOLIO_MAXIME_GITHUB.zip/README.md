# Portfolio — Maxime Hamer

Portfolio UX/UI responsive adapté de la maquette Figma. Il contient les versions clair/sombre, les projets Orbit, Mood.fm, Dernière Séance, APWAP et Néo : Survie, ainsi qu’une page de mentions légales.

## Publier sur GitHub Pages

1. Décompresser le fichier ZIP.
2. Ouvrir le dossier décompressé et déposer **son contenu**, y compris `index.html`, à la racine du dépôt GitHub.
3. Dans le dépôt, ouvrir **Settings → Pages**. Sous « Build and deployment », choisir **Deploy from a branch**, la branche `main` et le dossier `/ (root)`, puis enregistrer.
4. Patienter le temps du déploiement ; GitHub indique ensuite l’adresse du site sur la page Pages.

Aucun `npm install` ni compilation n’est nécessaire. Pour tester, ouvrir `index.html` avec un serveur local, par exemple `python3 -m http.server 8000`, puis visiter `http://localhost:8000/`.

## À compléter avant publication

- Dans `mentions-legales.html`, compléter les informations de l’éditeur nécessaires selon ton statut et confirmer le numéro de téléphone de l’hébergeur. Vérifier l’hébergeur si tu n’utilises pas GitHub Pages.
- Vérifier que tu disposes des autorisations nécessaires pour les images, logos, musiques et autres contenus tiers présents dans les projets. Les maquettes et jeux peuvent contenir des contenus de démonstration.
- Les liens vers les projets sont relatifs : conserver les dossiers `orbit`, `moodfm`, `derniere-seance`, `projets`, `matrix` et `assets`.
- Les polices de la nouvelle page d’accueil sont chargées depuis Google Fonts ; les projets existants peuvent utiliser leurs propres ressources externes. Consulter la page de confidentialité avant d’ajouter des outils de mesure ou de nouveaux traceurs.
- Vérifier la politique de données et les mentions des projets liés séparément, en particulier pour leurs services externes.

## Structure

- `index.html` : accueil du portfolio.
- `portfolio.css`, `portfolio.js` : style, thèmes et interactions de l’accueil.
- `mentions-legales.html` : mentions légales et informations de confidentialité.
- `orbit/`, `moodfm/`, `derniere-seance/`, `matrix/`, `projets/` : projets présentés.
- `assets/` et fichiers associés : images et ressources des projets.
